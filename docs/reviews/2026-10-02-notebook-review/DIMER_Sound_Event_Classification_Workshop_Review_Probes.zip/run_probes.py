"""Review probes for DIMER_Sound_Event_Classification_Workshop.ipynb (Notebook Review Framework v1).

CPU-only direct execution of the carried worker's model-free functions plus static source checks.
No model is loaded and no GPU is used. Usage:

    python run_probes.py --repo <repo checkout> [--out results.json] [--manifest source_manifest.json]
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.util
import json
import math
import struct
import sys
import tempfile
import traceback
from pathlib import Path

import numpy as np

NB = "tutorials/DIMER_Sound_Event_Classification_Workshop.ipynb"
RESULTS: dict[str, dict] = {}


def record(pid, title, basis, passed, observed):
    RESULTS[pid] = {"title": title, "evidence_basis": basis, "passed": passed, "observed": observed}


def load(repo: Path):
    nb = json.loads((repo / NB).read_text(encoding="utf-8"))
    carried_cell = next(c for c in nb["cells"] if "".join(c["source"]).startswith("CARRIED_FILES = "))
    body = ast.parse("".join(carried_cell["source"])).body
    files = ast.literal_eval(body[0].value)
    hashes = ast.literal_eval(body[1].value)
    return nb, files, hashes


def import_worker(files, tmp: Path):
    for name, text in files.items():
        p = tmp / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8", newline="\n")
    spec = importlib.util.spec_from_file_location("workshop_worker_probe", tmp / "workshop.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def wav_bytes(samples, rate=16000, fmt=1, bits=16, channels=1):
    data = samples.astype("<i2").tobytes() if bits == 16 else samples.astype("<f4").tobytes()
    align = channels * bits // 8
    fmt_chunk = struct.pack("<HHIIHH", fmt, channels, rate, rate * align, align, bits)
    body = b"WAVE" + b"fmt " + struct.pack("<I", 16) + fmt_chunk + b"data" + struct.pack("<I", len(data)) + data
    return b"RIFF" + struct.pack("<I", len(body)) + body


def error_of(fn, *args, **kwargs):
    try:
        fn(*args, **kwargs)
    except Exception as exc:  # noqa: BLE001 - probes record the learner-facing error
        return f"{type(exc).__name__}: {exc}"
    return None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", type=Path, required=True)
    ap.add_argument("--out", type=Path, default=Path("results.json"))
    ap.add_argument("--manifest", type=Path, default=Path("source_manifest.json"))
    args = ap.parse_args()
    repo = args.repo.resolve()
    nb, files, hashes = load(repo)
    cells = ["".join(c["source"]) for c in nb["cells"]]
    # Learner-facing code cells only: the carried payload cell embeds the worker source as strings.
    code = [s for s, c in zip(cells, nb["cells"], strict=True)
            if c["cell_type"] == "code" and not s.startswith("CARRIED_FILES = ")]
    md = [s for s, c in zip(cells, nb["cells"], strict=True) if c["cell_type"] == "markdown"]

    # P00 carried-file integrity (the notebook's own check).
    ok = all(hashlib.sha256(t.encode()).hexdigest() == hashes[n] for n, t in files.items())
    record("P00", "Carried files match CARRIED_HASHES", "direct execution (CPU)", ok, {"files": len(files)})

    tmp = Path(tempfile.mkdtemp(prefix="sec_probe_"))
    w = import_worker(files, tmp)
    names = json.loads(files["sample.json"])["class_names"]

    # P01 metric definitions on a hand-computed toy case.
    m = w.metrics([0, 0, 0, 1, 1, 2], [0, 0, 1, 1, 1, 0], ["a", "b", "c"])
    expect_f1 = {"a": 2 * 2 / (3 + 3), "b": 2 * 2 / (2 + 3), "c": 0.0}
    ok = (
        math.isclose(m["accuracy"], 4 / 6)
        and all(math.isclose(m["per_class"][k]["f1"], v) for k, v in expect_f1.items())
        and m["per_class"]["c"]["precision"] is None
        and m["per_class"]["c"]["precision_reason"] == "no predicted positives"
    )
    record("P01", "Metric formulas, macro denominator and undefined precision", "direct execution (CPU)", ok,
           {"accuracy": m["accuracy"], "macro_f1": m["macro_f1"], "c_precision": m["per_class"]["c"]["precision"]})

    # P02 frozen split integrity and activity selection from the carried sample manifest.
    sample = json.loads(files["sample.json"])
    recs = sample["records"]
    roles = {}
    for r in recs:
        roles.setdefault(r["group_id"], set()).add(r["role"])
    per = {(r["role"], r["label"]) for r in recs}
    counts = {role: sum(r["role"] == role for r in recs) for role in ("train", "validation", "test")}
    groups = {role: len({r["group_id"] for r in recs if r["role"] == role}) for role in counts}
    ids = w.activity_ids(recs, names)
    by_id = {r["id"]: r for r in recs}
    distinct = sum(by_id[ids[2 * i]]["group_id"] != by_id[ids[2 * i + 1]]["group_id"] for i in range(10))
    ok = (counts == {"train": 240, "validation": 80, "test": 80} and all(len(v) == 1 for v in roles.values())
          and len(per) == 30 and len(ids) == 20 and all(by_id[i]["role"] == "validation" for i in ids))
    record("P02", "Frozen 240/80/80 split, source-group isolation, 20 activity clips", "direct execution (CPU)", ok,
           {"counts": counts, "groups": groups, "activity_pairs_with_distinct_groups": distinct})

    # P03 noise construction: measured SNR, common gain, no clipping, one realization reused.
    rng = np.random.default_rng(7)
    x = (0.4 * np.sin(np.linspace(0, 400 * np.pi, 80000)) + 0.05 * rng.normal(size=80000)).astype(np.float32)
    cond = w.noise_conditions(x, "probe-clip")
    snrs = {c["condition"]: c["actual_snr_db"] for c in cond}
    ok = (all(abs(snrs[k] - float(k)) < 0.05 for k in ("20", "10", "0")) and len({c["gain"] for c in cond}) == 1
          and all(c["clipped_samples"] == 0 for c in cond) and len({c["noise_sha256"] for c in cond}) == 1)
    record("P03", "Noise SNR/gain/clipping contract", "direct execution (CPU)", ok,
           {"measured_snr_db": snrs, "gain": cond[0]["gain"]})

    # P04 BYOD validation messages (DAT19 / UX10): do they name the failing class, role, group or count?
    def rec(i, role, label, group):
        return {"id": f"c{i}", "role": role, "label": label, "group_id": group, "waveform_sha256": f"w{i}",
                "mono_sha256": f"m{i}", "seconds": 1.0}

    good = []
    i = 0
    for label in range(2):
        for role, n in (("train", 4), ("validation", 2), ("test", 2)):
            for k in range(n):
                good.append(rec(i, role, label, f"{role}-{label}-{k}"))
                i += 1
    msgs = {}
    short = good[:-1]  # one test clip of class 1 missing
    msgs["class_support"] = error_of(w.validate_records, short, ["owl", "frog"], byod=True)
    cross = [dict(r) for r in good]
    cross[-1]["group_id"] = cross[0]["group_id"]
    msgs["group_crosses_roles"] = error_of(w.validate_records, cross, ["owl", "frog"], byod=True)
    one_group = [dict(r) for r in good]
    for r in one_group:
        if r["role"] == "validation" and r["label"] == 0:
            r["group_id"] = "same"
    msgs["groups_per_role"] = error_of(w.validate_records, one_group, ["owl", "frog"], byod=True)
    missing_role = [dict(r) for r in good]
    missing_role[3].pop("role")
    msgs["missing_role_key"] = error_of(w.validate_records, missing_role, ["owl", "frog"], byod=True)
    specific = {
        "class_support": bool(msgs["class_support"]) and "frog" in msgs["class_support"] and "test" in msgs["class_support"],
        "group_crosses_roles": bool(msgs["group_crosses_roles"]) and cross[0]["group_id"] in msgs["group_crosses_roles"],
        "groups_per_role": bool(msgs["groups_per_role"]) and "owl" in msgs["groups_per_role"],
        "missing_role_key": bool(msgs["missing_role_key"]) and "role" in msgs["missing_role_key"] and "KeyError" not in msgs["missing_role_key"],
    }
    record("P04", "BYOD validation errors name the failed class/role/group/field", "direct execution (CPU)",
           all(specific.values()), {"messages": msgs, "specific": specific})

    # P05 BYOD prepare with a manifest record missing 'audio' (raw KeyError vs actionable message).
    byod = tmp / "byod"
    (byod / "wav").mkdir(parents=True)
    tone = (8000 * np.sin(np.linspace(0, 200 * np.pi, 16000))).astype(np.int16)
    (byod / "wav" / "a.wav").write_bytes(wav_bytes(tone))
    manifest = {"class_names": ["owl", "frog"], "records": [{"id": "a", "label": "owl", "group_id": "g", "role": "train"}]}
    (byod / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    root = tmp / "root"
    (root / "outputs").mkdir(parents=True)
    msg = error_of(w.prepare, root, byod)
    record("P05", "BYOD record without 'audio' gives an actionable message", "direct execution (CPU)",
           bool(msg) and "KeyError" not in msg and "audio" in msg, {"message": msg})

    # P06 WAV header contract: accepted and refused inputs.
    hdr = {}
    for label, payload in {
        "pcm16_mono_16k_1s": wav_bytes(tone),
        "extensible_pcm16": wav_bytes(tone, fmt=0xFFFE),
        "pcm16_11s": wav_bytes(np.zeros(16000 * 11, dtype=np.int16)),
    }.items():
        p = tmp / f"{label}.wav"
        p.write_bytes(payload)
        hdr[label] = error_of(w.audio_header, p)
    silent = tmp / "silent.wav"
    silent.write_bytes(wav_bytes(np.zeros(16000, dtype=np.int16)))
    hdr["silent_read_audio"] = error_of(w.read_audio, silent)
    ok = hdr["pcm16_mono_16k_1s"] is None and all(hdr[k] for k in ("extensible_pcm16", "pcm16_11s", "silent_read_audio"))
    record("P06", "WAV header bounds and refusals", "direct execution (CPU)", ok, hdr)

    # P07 stage receipts: re-running Section 6 (reload) then Section 8 (report).
    sroot = tmp / "stages"
    (sroot / "outputs").mkdir(parents=True)
    (sroot / "weights/ast").mkdir(parents=True)
    for name in ("source.json", "requirements.txt", "sample.json"):
        (sroot / name).write_text(files[name], encoding="utf-8")
    (sroot / "weights/ast/dimer-base-manifest.json").write_text(files["weights/ast/dimer-base-manifest.json"], encoding="utf-8")
    for outputs in w.STAGE_FILES.values():
        for name in outputs:
            (sroot / "outputs" / name).write_text("x", encoding="utf-8")
    (sroot / "outputs/records.json").write_text("[]", encoding="utf-8")
    for stage in w.STAGES:
        w.finish_stage(sroot, stage, w.begin_stage(sroot, stage))
    w.finish_stage(sroot, "reload", w.begin_stage(sroot, "reload"))
    msg = error_of(w.begin_stage, sroot, "report")
    record("P07", "Stale-stage message names the stage to re-run", "direct execution (CPU)",
           bool(msg) and "activity" in msg, {"rerun": "reload then report", "message": msg})

    # P08 static: duplicated stage log output.
    runner = next(s for s in code if "def run_stage" in s)
    body = runner.split("def run_stage", 1)[1].split("\nfrom IPython", 1)[0]
    tail_unconditional = "print(log.read_text(" in body and "if result.returncode" in body and body.index(
        "print(log.read_text(") < body.index("if result.returncode")
    record("P08", "Stage log is printed once on success", "source inspection", not tail_unconditional,
           {"streams_each_line": "print(line.rstrip()" in body, "prints_tail_unconditionally": tail_unconditional})

    # P09 static: paired errors / confusion pair / mistakes reach the learner.
    shows_paired = any("paired_errors" in s for s in code)
    template = next((s for s in md if "introduced [count] new errors" in s), "")
    record("P09", "Paired-error counts and an actual mistake are displayed for the conclusion template",
           "source inspection", shows_paired, {"code_cells_reading_paired_errors": sum("paired_errors" in s for s in code),
                                              "template_requests_counts": bool(template)})

    # P10 static: confusion figure ordering versus the Section 5 notice.
    notice_idx = next(i for i, s in enumerate(cells) if "Confusion rows are true labels" in s)
    fig_idx = next(i for i, s in enumerate(cells) if "confusion.png" in s and nb["cells"][i]["cell_type"] == "code"
                   and not s.startswith("CARRIED_FILES = "))
    record("P10", "Confusion figure is shown before (or with) the notice that explains it", "source inspection",
           fig_idx < notice_idx, {"notice_cell": notice_idx, "first_confusion_display_cell": fig_idx})

    # P11 static: selection saturation is surfaced.
    train_cell = next(s for s in code if "run_stage('train')" in s)
    record("P11", "Train cell reports epochs tied at the best validation score and updates in the selected head",
           "source inspection", "tied" in train_cell.lower() and "selected" in train_cell,
           {"mentions_ties": "tied" in train_cell.lower()})

    # P12 static: BYOD results displayed in the notebook.
    byod_cell = next(s for s in code if "RUN_BYOD = False" in s)
    shows = [k for k in ("metrics.json", "selection.json", "reload_parity.json", "noise_summary.json") if k in byod_cell]
    record("P12", "BYOD branch displays the user's metrics, selection, reload and noise results", "source inspection",
           len(shows) == 4, {"displayed": shows, "only_filelink": not shows})

    # P13 static: BYOD data-movement statement and sensitive-data warning (DAT17, DAT18).
    byod_md = next(s for s in md if "your own labelled recordings" in s)
    dat17 = any(k in byod_md for k in ("not sent", "not transmitted", "does not send", "stays in", "remain in"))
    dat18 = all(k in byod_md.lower() for k in ("confidential", "personal"))
    upload_howto = "Files" in byod_md and "folder" in byod_md.lower()
    record("P13", "BYOD prose states data movement, warns on sensitive data, explains how to place files", "source inspection",
           dat17 and dat18 and upload_howto, {"DAT17": dat17, "DAT18": dat18, "upload_howto": upload_howto})

    # P14 static: ENV3 version display.
    setup = next(s for s in code if "UV_URL" in s)
    shown = [lib for lib in ("torch", "torchaudio", "transformers") if f"{lib}.__version__" in setup]
    record("P14", "Principal library versions displayed (ENV3)", "source inspection",
           shown == ["torch", "torchaudio", "transformers"], {"displayed": shown})

    # P15 registry row consistency.
    readme = (repo / "tutorials/README.md").read_text(encoding="utf-8")
    row = next(line for line in readme.splitlines() if "`DIMER_Sound_Event_Classification_Workshop.ipynb`" in line)
    stale = "not yet recorded" in row
    record("P15", "Registry Run-all cell agrees with recorded hosted evidence", "source inspection", not stale,
           {"row_says_not_yet_recorded": stale})

    args.out.write_text(json.dumps({"notebook": NB, "results": RESULTS}, indent=2) + "\n", encoding="utf-8")
    manifest_paths = [NB, "tutorials/README.md", "docs/release-verification.md",
                      "docs/sound-event-classification-workshop-spec.md", "tools/validate_release_assets.py",
                      "tests/test_workshop_notebook.py", ".github/workflows/ci.yml"]
    src = {p: hashlib.sha256((repo / p).read_bytes()).hexdigest() for p in manifest_paths}
    src.update({f"carried:{n}": h for n, h in hashes.items()})
    args.manifest.write_text(json.dumps(src, indent=2) + "\n", encoding="utf-8")
    for pid, r in RESULTS.items():
        print(pid, "PASS" if r["passed"] else "FAIL", "-", r["title"])
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:
        traceback.print_exc()
        sys.exit(2)
