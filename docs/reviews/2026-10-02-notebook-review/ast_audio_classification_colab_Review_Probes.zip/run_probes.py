"""Review probes for tutorials/ast_audio_classification_colab.ipynb (AST-*), CPU only, no model download.

Usage: python run_probes.py <repo_worktree>   (numpy required; torch/transformers NOT needed)
Writes results.json and source_manifest.json next to this script.
"""
import ast
import contextlib
import hashlib
import importlib.util
import io
import json
import os
import subprocess
import sys
import tempfile
import types
import wave
import zipfile
from pathlib import Path

import numpy as np

REPO = Path(sys.argv[1]).resolve()
HERE = Path(__file__).resolve().parent
NB = REPO / 'tutorials' / 'ast_audio_classification_colab.ipynb'
results = {}


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


nb = json.loads(NB.read_text(encoding='utf-8'))
cells = nb['cells']


def src(i):
    return ''.join(cells[i]['source'])


def md_cells():
    return [src(i) for i, c in enumerate(cells) if c['cell_type'] == 'markdown']


# P1 notebook structure: parse, compile, outputs cleared, metadata
compile_errors = []
for i, c in enumerate(cells):
    if c['cell_type'] == 'code':
        try:
            compile(src(i), f'cell{i}', 'exec')
        except SyntaxError as e:
            compile_errors.append((i, str(e)))
results['P1_structure'] = {
    'nbformat': [nb['nbformat'], nb['nbformat_minor']],
    'n_cells': len(cells),
    'n_code': sum(c['cell_type'] == 'code' for c in cells),
    'compile_errors': compile_errors,
    'persisted_outputs': sum(len(c.get('outputs', [])) for c in cells if c['cell_type'] == 'code'),
    'metadata_dimer': nb['metadata'].get('dimer'),
    'git_blob': subprocess.run(['git', '-C', str(REPO), 'rev-parse', 'HEAD:tutorials/ast_audio_classification_colab.ipynb'],
                               capture_output=True, text=True).stdout.strip(),
}

# P2 generator parity (stdlib only)
r = subprocess.run([sys.executable, str(REPO / 'tools' / 'build_notebook.py'), '--check'], cwd=REPO,
                   capture_output=True, text=True)
results['P2_generator_check'] = {'exit': r.returncode, 'tail': (r.stdout + r.stderr)[-400:]}

# Load carried modules (numpy-only paths)
sys.path.insert(0, str(REPO / 'src'))
from ast_audio_classification_pipeline import metrics, samples  # noqa: E402

spec = importlib.util.spec_from_file_location('pl', REPO / 'src/ast_audio_classification_pipeline/pipeline.py')
pl = importlib.util.module_from_spec(spec)
sys.modules['pl'] = pl
spec.loader.exec_module(pl)

# P3 duplicate / leakage check of the default synthetic dataset and split (exact notebook calls)
recs = samples.synthetic_audio_dataset(n_samples=24, seed=42)
digest = {rec['id']: hashlib.sha256(rec['waveform'].tobytes()).hexdigest() for rec in recs}
by_class = {}
for rec in recs:
    by_class.setdefault(rec['class_name'], set()).add(digest[rec['id']])
train, val = samples.split_dataset(recs, val_fraction=0.25, seed=42)
train_d = {digest[rec['id']] for rec in train}
val_dup = [{'id': rec['id'], 'class': rec['class_name'], 'identical_to_a_train_clip': digest[rec['id']] in train_d}
           for rec in val]
test_clip = samples.generate_audio_clip(index=99, class_idx=1, duration=3.0, sample_rate=16000)
test_d = hashlib.sha256(test_clip.tobytes()).hexdigest()
results['P3_dataset_duplicates'] = {
    'distinct_waveforms_per_class': {k: len(v) for k, v in by_class.items()},
    'records_per_class': {k: sum(rec['class_name'] == k for rec in recs) for k in samples.ADAPT_CLASSES},
    'train_counts': {k: sum(rec['class_name'] == k for rec in train) for k in samples.ADAPT_CLASSES},
    'val_records': val_dup,
    'val_identical_to_train': sum(v['identical_to_a_train_clip'] for v in val_dup),
    'unseen_clip_99_identical_to_any_dataset_clip': test_d in set(digest.values()),
}

# P4 majority baseline source: computed from evaluation targets
results['P4_baseline_source'] = {
    'evidence': 'metrics.py evaluate_classification: baseline = majority_class_baseline(targets, num_classes)',
    'val_majority': metrics.majority_class_baseline([rec['label'] for rec in val], 3),
}


# P5 BYOD dataset ZIP branch: execute cell 17 with a google.colab stub (no model needed)
def wav_bytes(seconds=1.0, rate=16000, width=2, channels=1, freq=440.0):
    n = int(seconds * rate)
    t = np.arange(n) / rate
    x = 0.3 * np.sin(2 * np.pi * freq * t)
    buf = io.BytesIO()
    with wave.open(buf, 'wb') as w:
        w.setnchannels(channels)
        w.setsampwidth(width)
        w.setframerate(rate)
        frames = np.repeat((x * 32767).astype('<i2'), channels)
        w.writeframes(frames.tobytes())
    return buf.getvalue()


def make_zip(entries):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w') as z:
        for name, data in entries:
            z.writestr(name, data)
    return buf.getvalue()


classes = samples.ADAPT_CLASSES
valid = [(f'{c}/{c}_{k}.wav', wav_bytes(freq=200 + 300 * i + 7 * k)) for i, c in enumerate(classes) for k in range(2)]
cases = {
    'valid_2_per_class': valid,
    'nested_parent_folder': [(f'mydata/{n}', d) for n, d in valid],
    'macosx_metadata': valid + [('__MACOSX/geophony/._geophony_0.wav', b'\x00' * 10)],
    'rate_44100': [(n, wav_bytes(rate=44100)) for n, _ in valid],
    'missing_class': [e for e in valid if not e[0].startswith('anthrophony')],
    'over_long_11s': [(n, wav_bytes(seconds=11.0)) for n, _ in valid],
    'stereo_16k': [(n, wav_bytes(channels=2)) for n, _ in valid],
}
cell15 = ast.parse(src(15))
decode_node = next(n for n in cell15.body if isinstance(n, ast.FunctionDef) and n.name == 'decode_pcm_wav')
decode_src = ast.get_source_segment(src(15), decode_node)
byod = {}
for name, entries in cases.items():
    payload = make_zip(entries)
    colab = types.ModuleType('google.colab')
    g = types.ModuleType('google')
    colab.files = types.SimpleNamespace(upload=lambda p=payload: {'dataset.zip': p})
    g.colab = colab
    sys.modules['google'] = g
    sys.modules['google.colab'] = colab
    body = src(17).replace('USE_BYOD_DATASET = False', 'USE_BYOD_DATASET = True')
    ns = {'np': np, 'io': io, 'wave': wave, 'ADAPT_CLASSES': classes, 'validate_dataset': samples.validate_dataset,
          'synthetic_audio_dataset': samples.synthetic_audio_dataset, 'validate_inputs': pl.validate_inputs,
          'MAX_INPUT_SECONDS': pl.MAX_INPUT_SECONDS, 'SAMPLE_RATE': 16000,
          'audio': samples.tutorial_tone(), 'sample_rate': 16000, 'clip_name': 'tone.wav'}
    exec(decode_src, ns)
    cwd = os.getcwd()
    os.chdir(tempfile.mkdtemp())
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            exec(body, ns)
        out = {'accepted': True, 'n_records': len(ns['dataset_records'])}
        tr, va = samples.split_dataset(ns['dataset_records'], val_fraction=0.25, seed=42)
        out['split'] = [len(tr), len(va)]
    except Exception as e:  # noqa: BLE001 - recorded as the learner-facing message
        out = {'accepted': False, 'error': f'{type(e).__name__}: {e}'}
    finally:
        os.chdir(cwd)
    byod[name] = out
results['P5_byod_zip_branch'] = byod

# P6 static checks
mds = md_cells()
low = [m.lower() for m in mds]
results['P6_static'] = {
    'restart_raise_in_install_cell': 'Restart the runtime, then rerun from the top' in src(3),
    'decision_rule_stated_in_markdown': any('argmax' in m or 'decision rule' in m or 'highest' in m for m in low),
    'calibration_caveat_for_softmax_in_markdown': any('softmax' in m and 'calibrat' in m for m in low),
    'macro_f1_explained_in_markdown': any('macro' in m and ('average' in m or 'unweighted' in m) for m in low),
    'random_split_independence_stated': any('split' in m and 'independent row' in m for m in low),
    'guided_markers': {k: any(k.lower() in m for m in low) for k in
                       ['How to use this notebook', 'Roadmap', 'Glossary', 'Prediction', 'What to notice',
                        'Check your', 'Troubleshooting', '## Exercise', 'Optional experiment', 'Change one thing']},
    'infrastructure_label_or_cellview_form': any('Infrastructure' in src(i) or c.get('metadata', {}).get('cellView') == 'form'
                                                 for i, c in enumerate(cells)),
    'module_cell_chars': {i: len(src(i)) for i in (5, 7, 9)},
    'pre_eval_exported': 'pre_eval' in src(25) or 'pre_eval' in src(33),
    'cpu_time_claim_in_opening': '10–15 s on CPU' in src(0),
}

(HERE / 'results.json').write_text(json.dumps(results, indent=2, default=str), encoding='utf-8')
files = ['tutorials/ast_audio_classification_colab.ipynb', 'src/ast_audio_classification_pipeline/pipeline.py',
         'src/ast_audio_classification_pipeline/samples.py', 'src/ast_audio_classification_pipeline/metrics.py',
         'tools/notebook_template.py', 'tools/build_notebook.py', 'tutorials/README.md', 'docs/release-verification.md',
         'docs/verification/2026-09-16-kaggle-t4/README.md',
         'docs/verification/2026-09-16-kaggle-t4/suite/dimer-nb2-ast-audio-classification/v3/evidence/executed-pass1.ipynb']
(HERE / 'source_manifest.json').write_text(json.dumps({f: sha(REPO / f) for f in files}, indent=2), encoding='utf-8')
print(json.dumps(results, indent=2, default=str))
